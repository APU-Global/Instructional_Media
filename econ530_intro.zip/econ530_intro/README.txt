ECON 530 (MBA530) Course Introduction - rebuilt as plain HTML from the Captivate source file
============================================================================================
Open index.html. It starts by itself after a loading spinner, like your ECON 203 intro.

Files
  index.html          the whole player (HTML + CSS + JS, no libraries)
  goodbye.html        exit page (the X button goes here)
  assets/media/       intro-theme.mp4  (the 10-second skyline video from the project)
  assets/audio/       narration.mp3 (the narrator, 29.7 s), music-stinger.mp3 (9 s), music-bed.mp3 (Bensound)
  assets/img/         the 17 illustrations from the project
  assets/playbar/     Captivate-style playbar images (same ones used for the ECON 203 intro)
  assets/ui/          loading spinner

What came straight from the .cptx
  * the video, the narration, both music files, all illustrations
  * the three narrated sentences (shown in speech bubbles)
  * the slide colour (#6CA5B7), the "COURSE INTRODUCTION" title colours, the music credit

What was reconstructed (a .cptx cannot be played without Captivate)
  * exact positions and start/end times of each picture
  * which picture appears with which part of the narration
  * the timing of the words (measured from the pauses in the narration)
  * which music plays where
  If you can send the PUBLISHED Captivate output for this lesson (index.html plus its assets,
  dr, ar and vr folders), the layout and timing can be matched exactly, as was done for ECON 203.

GitHub Pages
  1. Put this whole folder in a repo (keep index.html and assets/ together).
  2. Settings > Pages > deploy from the main branch.
  3. Your page will be at  https://YOUR-USER.github.io/YOUR-REPO/econ530_intro/index.html

Canvas (Rich Content Editor > </> HTML view)
  <iframe src="https://YOUR-USER.github.io/YOUR-REPO/econ530_intro/index.html"
          width="100%" height="560" style="border:0;"
          title="Course Introduction"
          allow="autoplay; fullscreen" allowfullscreen></iframe>
  The player scales to fit the frame, so it never makes its own scrollbar.

Easy edits (top of the <script> in index.html)
  SLIDE1_LEN / N0 / TOTAL      slide lengths and when the narration starts
  SENT                         the sentences and the time each phrase is spoken
  PICS                         each picture: file, position, size, when it appears and leaves
  AUDIO                        which sound plays when, and how loud

Notes
  * Browsers only allow sound after a click or key press; the sound icon shows "off" until then.
  * Spelling: the source text had a typo ("techniquyes"); it is corrected here.
